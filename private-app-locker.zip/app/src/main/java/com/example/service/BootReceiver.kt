package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.AppLockerDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val settings = AppLockerDatabase.getInstance(context).appLockerDao().getSecuritySettingsSync()
                    if (settings?.isProtectionServiceActive == true && PermissionHelper.hasUsageStatsPermission(context)) {
                        AppLockerForegroundService.startService(context)
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
