package com.example.data.repository

import android.content.Context
import com.example.data.dao.AppLockerDao
import com.example.data.model.IntruderLogEntity
import com.example.data.model.LockedAppEntity
import com.example.data.model.PrivateVaultItemEntity
import com.example.data.model.SecuritySettingsEntity
import com.example.service.AppScanner
import com.example.service.InstalledAppInfo
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class AppLockerRepository(
    private val dao: AppLockerDao,
    private val context: Context
) {

    val allLockedApps: Flow<List<LockedAppEntity>> = dao.getAllLockedApps()
    val activeLockedApps: Flow<List<LockedAppEntity>> = dao.getActiveLockedApps()
    val intruderLogs: Flow<List<IntruderLogEntity>> = dao.getAllIntruderLogs()
    val vaultItems: Flow<List<PrivateVaultItemEntity>> = dao.getAllVaultItems()
    val securitySettings: Flow<SecuritySettingsEntity?> = dao.getSecuritySettings()

    suspend fun getInstalledApps(): List<InstalledAppInfo> {
        return AppScanner.getInstalledApps(context)
    }

    suspend fun toggleAppLock(packageName: String, appName: String, category: String, isCurrentlyLocked: Boolean) {
        val existing = dao.getLockedApp(packageName)
        if (existing != null) {
            dao.updateLockStatus(packageName, !isCurrentlyLocked)
        } else {
            dao.insertLockedApp(
                LockedAppEntity(
                    packageName = packageName,
                    appName = appName,
                    isLocked = true,
                    category = category
                )
            )
        }
    }

    suspend fun setCamouflage(packageName: String, enabled: Boolean) {
        dao.updateCamouflage(packageName, enabled)
    }

    suspend fun lockMultipleApps(apps: List<InstalledAppInfo>) {
        val entities = apps.map {
            LockedAppEntity(
                packageName = it.packageName,
                appName = it.appName,
                isLocked = true,
                category = it.category
            )
        }
        dao.insertLockedApps(entities)
    }

    suspend fun unlockAllApps() {
        val all = dao.getAllLockedApps().firstOrNull() ?: emptyList()
        all.forEach {
            dao.updateLockStatus(it.packageName, false)
        }
    }

    suspend fun recordIntruderAttempt(packageName: String, appName: String, failedCount: Int, maskedCode: String) {
        dao.insertIntruderLog(
            IntruderLogEntity(
                timestamp = System.currentTimeMillis(),
                packageName = packageName,
                appName = appName,
                failedAttempts = failedCount,
                enteredCodeMasked = maskedCode
            )
        )
    }

    suspend fun clearIntruderLogs() {
        dao.clearAllIntruderLogs()
    }

    suspend fun deleteIntruderLog(id: Long) {
        dao.deleteIntruderLog(id)
    }

    // Vault
    suspend fun saveVaultItem(item: PrivateVaultItemEntity) {
        dao.insertVaultItem(item)
    }

    suspend fun deleteVaultItem(item: PrivateVaultItemEntity) {
        dao.deleteVaultItem(item)
    }

    suspend fun deleteVaultItemById(id: Long) {
        dao.deleteVaultItemById(id)
    }

    // Settings
    suspend fun getSettingsSync(): SecuritySettingsEntity? {
        return dao.getSecuritySettingsSync()
    }

    suspend fun saveSettings(settings: SecuritySettingsEntity) {
        dao.saveSecuritySettings(settings)
    }
}
