package com.example.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.example.data.AppLockerDatabase
import com.example.data.model.IntruderLogEntity
import com.example.service.SessionManager
import com.example.ui.components.FakeCrashDialog
import com.example.ui.screens.AuthLockScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LockOverlayActivity : ComponentActivity() {

    private var targetPackage: String = ""
    private var targetAppName: String = "Protected Application"
    private var isCamouflage: Boolean = false
    private var targetAppIcon: Drawable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        targetPackage = intent.getStringExtra(EXTRA_LOCKED_PACKAGE) ?: ""
        targetAppName = intent.getStringExtra(EXTRA_APP_NAME) ?: "Protected Application"
        isCamouflage = intent.getBooleanExtra(EXTRA_CAMOUFLAGE, false)

        if (targetPackage.isNotEmpty()) {
            try {
                targetAppIcon = packageManager.getApplicationIcon(targetPackage)
            } catch (_: PackageManager.NameNotFoundException) {
                targetAppIcon = null
            }
        }

        // When user tries to press Back on the Lock Screen, send them to home launcher to keep app protected
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                goToHomeScreen()
            }
        })

        val db = AppLockerDatabase.getInstance(applicationContext)
        val dao = db.appLockerDao()

        setContent {
            MyApplicationTheme {
                val settings by dao.getSecuritySettings().collectAsState(initial = null)
                var showCamouflage by remember { mutableStateOf(isCamouflage) }

                Box(modifier = Modifier.fillMaxSize()) {
                    settings?.let { secSettings ->
                        AnimatedVisibility(
                            visible = showCamouflage,
                            enter = fadeIn(),
                            exit = fadeOut()
                        ) {
                            FakeCrashDialog(
                                appName = targetAppName,
                                onRevealLock = { showCamouflage = false },
                                onRealExit = { goToHomeScreen() }
                            )
                        }

                        if (!showCamouflage) {
                            AuthLockScreen(
                                settings = secSettings,
                                targetAppName = targetAppName,
                                targetAppIcon = targetAppIcon,
                                targetPackageName = targetPackage,
                                onUnlockSuccess = {
                                    SessionManager.unlockPackage(targetPackage, secSettings.relockTimeoutSeconds)
                                    finish()
                                },
                                onIntruderAttempt = { pkg, name, count, code ->
                                    lifecycleScope.launch(Dispatchers.IO) {
                                        dao.insertIntruderLog(
                                            IntruderLogEntity(
                                                packageName = pkg,
                                                appName = name,
                                                failedAttempts = count,
                                                enteredCodeMasked = code
                                            )
                                        )
                                    }
                                },
                                onCloseOrExit = { goToHomeScreen() }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun goToHomeScreen() {
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(homeIntent)
        finish()
    }

    companion object {
        const val EXTRA_LOCKED_PACKAGE = "extra_locked_package"
        const val EXTRA_APP_NAME = "extra_app_name"
        const val EXTRA_CAMOUFLAGE = "extra_camouflage"
    }
}
