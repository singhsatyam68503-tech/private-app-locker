package com.example.service

import java.util.concurrent.ConcurrentHashMap

object SessionManager {
    // PackageName -> Expiration timestamp (millis)
    private val unlockedSessions = ConcurrentHashMap<String, Long>()

    var isMainAppUnlocked: Boolean = false
    var currentForegroundPackage: String = ""

    fun unlockPackage(packageName: String, timeoutSeconds: Int) {
        val expiry = if (timeoutSeconds <= 0) {
            // Immediate: valid for 15 seconds to allow app launch to settle without re-triggering immediately
            System.currentTimeMillis() + 15_000L
        } else {
            System.currentTimeMillis() + (timeoutSeconds * 1000L)
        }
        unlockedSessions[packageName] = expiry
    }

    fun isPackageUnlocked(packageName: String): Boolean {
        val expiry = unlockedSessions[packageName] ?: return false
        if (System.currentTimeMillis() > expiry) {
            unlockedSessions.remove(packageName)
            return false
        }
        return true
    }

    fun lockPackage(packageName: String) {
        unlockedSessions.remove(packageName)
    }

    fun lockAll() {
        unlockedSessions.clear()
        isMainAppUnlocked = false
    }

    fun onForegroundPackageChanged(newPackage: String, relockImmediate: Boolean) {
        if (currentForegroundPackage.isNotEmpty() && currentForegroundPackage != newPackage) {
            if (relockImmediate) {
                // Relock immediately upon leaving app
                unlockedSessions.remove(currentForegroundPackage)
            }
        }
        currentForegroundPackage = newPackage
    }
}
