package com.example.service

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val icon: Drawable?,
    val isSystemApp: Boolean,
    val category: String,
    val isRecommended: Boolean
)

object AppScanner {

    private val SOCIAL_KEYWORDS = listOf(
        "whatsapp", "telegram", "instagram", "facebook", "twitter", "x.com",
        "tiktok", "snapchat", "reddit", "messenger", "discord", "signal",
        "wechat", "viber", "line", "threads", "linkedin"
    )

    private val FINANCE_KEYWORDS = listOf(
        "pay", "bank", "wallet", "crypto", "binance", "coinbase", "revolut",
        "cash", "finance", "chase", "wells", "citi", "paypal", "venmo", "zelle"
    )

    private val SYSTEM_PACKAGES = listOf(
        "com.android.settings", "com.google.android.apps.photos", "com.android.camera",
        "com.google.android.GoogleCamera", "com.google.android.contacts",
        "com.android.vending", "com.android.dialer", "com.google.android.dialer"
    )

    private val SENSITIVE_KEYWORDS = listOf(
        "photo", "gallery", "message", "sms", "mail", "gmail", "setting",
        "camera", "drive", "file", "note", "contact"
    )

    suspend fun getInstalledApps(context: Context): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
        val myPackage = context.packageName

        val apps = mutableListOf<InstalledAppInfo>()
        val seenPackages = mutableSetOf<String>()

        for (info in resolveInfos) {
            val pkg = info.activityInfo.packageName
            if (pkg == myPackage || seenPackages.contains(pkg)) continue
            seenPackages.add(pkg)

            val appName = try {
                info.loadLabel(pm).toString()
            } catch (_: Exception) {
                pkg
            }

            val icon = try {
                info.loadIcon(pm)
            } catch (_: Exception) {
                null
            }

            val isSystem = try {
                val appInfo = pm.getApplicationInfo(pkg, 0)
                (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            } catch (_: Exception) {
                false
            }

            val pkgLower = pkg.lowercase()
            val nameLower = appName.lowercase()

            val category = when {
                SOCIAL_KEYWORDS.any { pkgLower.contains(it) || nameLower.contains(it) } -> "SOCIAL"
                FINANCE_KEYWORDS.any { pkgLower.contains(it) || nameLower.contains(it) } -> "FINANCE"
                SYSTEM_PACKAGES.contains(pkg) || (isSystem && (pkgLower.contains("settings") || pkgLower.contains("camera"))) -> "SYSTEM"
                pkgLower.contains("chrome") || pkgLower.contains("browser") || pkgLower.contains("gmail") || pkgLower.contains("mail") -> "TOOLS"
                isSystem -> "SYSTEM"
                else -> "OTHER"
            }

            val isRecommended = category == "SOCIAL" || category == "FINANCE" ||
                    SENSITIVE_KEYWORDS.any { pkgLower.contains(it) || nameLower.contains(it) }

            apps.add(
                InstalledAppInfo(
                    packageName = pkg,
                    appName = appName,
                    icon = icon,
                    isSystemApp = isSystem,
                    category = category,
                    isRecommended = isRecommended
                )
            )
        }

        // Sort alphabetically by app name
        apps.sortedBy { it.appName.lowercase() }
    }
}
