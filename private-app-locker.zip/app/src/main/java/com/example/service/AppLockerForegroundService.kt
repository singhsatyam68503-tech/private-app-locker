package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.AppLockerDatabase
import com.example.ui.LockOverlayActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AppLockerForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var monitorJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startAsForeground()
        startMonitoring()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "App Locker Protection",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors and locks protected applications"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun startAsForeground() {
        try {
            val launchIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                this,
                0,
                launchIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Private App Locker Active")
                .setContentText("Continuous real-time application protection is active")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Exception) {
            // Guard against foreground service policy restrictions in restricted emulator environments
        }
    }

    private fun startMonitoring() {
        monitorJob?.cancel()
        val dao = AppLockerDatabase.getInstance(applicationContext).appLockerDao()
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager

        monitorJob = serviceScope.launch {
            while (isActive) {
                try {
                    if (usm != null && PermissionHelper.hasUsageStatsPermission(applicationContext)) {
                        val foregroundPkg = getForegroundPackage(usm)
                        if (foregroundPkg != null && foregroundPkg != packageName) {
                            val settings = dao.getSecuritySettingsSync()
                            val relockImmediate = (settings?.relockTimeoutSeconds ?: 0) == 0

                            SessionManager.onForegroundPackageChanged(foregroundPkg, relockImmediate)

                            // Check if package is locked and not currently unlocked in session
                            val lockedEntity = dao.getLockedApp(foregroundPkg)
                            if (lockedEntity != null && lockedEntity.isLocked) {
                                if (!SessionManager.isPackageUnlocked(foregroundPkg)) {
                                    launchLockScreen(foregroundPkg, lockedEntity.appName, lockedEntity.isCamouflageEnabled)
                                }
                            }
                        }
                    }
                } catch (_: Exception) {
                    // Fail-safe swallow to keep monitor loop alive
                }
                delay(700L)
            }
        }
    }

    private fun getForegroundPackage(usm: UsageStatsManager): String? {
        val time = System.currentTimeMillis()
        val events = usm.queryEvents(time - 5000, time)
        val event = UsageEvents.Event()
        var lastResumedPkg: String? = null

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                lastResumedPkg = event.packageName
            }
        }
        return lastResumedPkg
    }

    private fun launchLockScreen(lockedPackage: String, appName: String, camouflage: Boolean) {
        val lockIntent = Intent(this, LockOverlayActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(LockOverlayActivity.EXTRA_LOCKED_PACKAGE, lockedPackage)
            putExtra(LockOverlayActivity.EXTRA_APP_NAME, appName)
            putExtra(LockOverlayActivity.EXTRA_CAMOUFLAGE, camouflage)
        }
        startActivity(lockIntent)
    }

    override fun onDestroy() {
        super.onDestroy()
        monitorJob?.cancel()
        serviceScope.cancel()
    }

    companion object {
        const val CHANNEL_ID = "app_locker_service_channel"
        const val NOTIFICATION_ID = 10101

        fun startService(context: Context) {
            try {
                val intent = Intent(context, AppLockerForegroundService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Exception) {
                // Safeguard against ForegroundServiceStartNotAllowedException
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, AppLockerForegroundService::class.java)
            context.stopService(intent)
        }
    }
}
