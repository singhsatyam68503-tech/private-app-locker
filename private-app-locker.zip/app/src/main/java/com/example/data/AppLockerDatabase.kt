package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.AppLockerDao
import com.example.data.model.IntruderLogEntity
import com.example.data.model.LockedAppEntity
import com.example.data.model.PrivateVaultItemEntity
import com.example.data.model.SecuritySettingsEntity

@Database(
    entities = [
        LockedAppEntity::class,
        IntruderLogEntity::class,
        PrivateVaultItemEntity::class,
        SecuritySettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppLockerDatabase : RoomDatabase() {
    abstract fun appLockerDao(): AppLockerDao

    companion object {
        @Volatile
        private var INSTANCE: AppLockerDatabase? = null

        fun getInstance(context: Context): AppLockerDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppLockerDatabase::class.java,
                    "app_locker_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
