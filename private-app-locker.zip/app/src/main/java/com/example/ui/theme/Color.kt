package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber Security Dark Theme Colors
val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDark = Color(0xFF00B4D8)
val CyberBlue = Color(0xFF0284C7)
val DeepNavy = Color(0xFF090D16)
val MidnightSlate = Color(0xFF0F172A)
val CardSlate = Color(0xFF1E293B)
val CardSlateLight = Color(0xFF334155)
val AccentGreen = Color(0xFF10B981)
val AccentRed = Color(0xFFEF4444)
val AccentAmber = Color(0xFFF59E0B)
val AccentViolet = Color(0xFF8B5CF6)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val BorderDark = Color(0xFF26334D)

// Material 3 mappings
val PrimaryDark = CyberCyan
val OnPrimaryDark = Color(0xFF00363D)
val PrimaryContainerDark = Color(0xFF004F58)
val OnPrimaryContainerDark = Color(0xFF80F2FF)

val SecondaryDark = Color(0xFF38BDF8)
val OnSecondaryDark = Color(0xFF003549)
val SecondaryContainerDark = Color(0xFF004D68)
val OnSecondaryContainerDark = Color(0xFFBAE6FD)

val BackgroundDark = DeepNavy
val SurfaceDark = MidnightSlate
val SurfaceVariantDark = CardSlate
