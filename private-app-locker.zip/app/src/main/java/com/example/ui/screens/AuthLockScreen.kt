package com.example.ui.screens

import android.graphics.drawable.Drawable
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pattern
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SecuritySettingsEntity
import com.example.service.SecurityUtils
import com.example.ui.components.AppIcon
import com.example.ui.components.PatternLockView
import com.example.ui.components.PinDotsIndicator
import com.example.ui.components.PinKeypad
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentRed
import com.example.ui.theme.BorderDark
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AuthLockScreen(
    settings: SecuritySettingsEntity,
    targetAppName: String? = null,
    targetAppIcon: Drawable? = null,
    targetPackageName: String? = null,
    onUnlockSuccess: () -> Unit,
    onIntruderAttempt: (packageName: String, appName: String, failedCount: Int, maskedCode: String) -> Unit,
    onCloseOrExit: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var currentPin by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var isSuccess by remember { mutableStateOf(false) }
    var failedAttempts by remember { mutableIntStateOf(0) }
    var showForgotDialog by remember { mutableStateOf(false) }
    var currentMethod by remember(settings.lockMethod) { mutableStateOf(settings.lockMethod) }

    // Recovery Question State
    var recoveryAnswer by remember { mutableStateOf("") }
    var recoveryError by remember { mutableStateOf(false) }

    // Animated colors and scales for unlock transition
    val iconBgColor by animateColorAsState(
        targetValue = if (isSuccess) AccentGreen.copy(alpha = 0.2f) else CyberCyan.copy(alpha = 0.12f),
        animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
        label = "icon_bg_color"
    )
    val iconTint by animateColorAsState(
        targetValue = if (isSuccess) AccentGreen else CyberCyan,
        animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
        label = "icon_tint"
    )
    val successScale by animateFloatAsState(
        targetValue = if (isSuccess) 1.15f else 1.0f,
        animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
        label = "success_scale"
    )

    fun triggerUnlockSuccess() {
        isSuccess = true
        isError = false
        if (settings.vibrateOnInput) {
            SecurityUtils.vibrateShort(context)
        }
        coroutineScope.launch {
            // Display smooth transition animation before calling unlock callback
            delay(400)
            onUnlockSuccess()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepNavy)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        // Exit / Back icon if enabled
        if (onCloseOrExit != null && !isSuccess) {
            IconButton(
                onClick = onCloseOrExit,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .testTag("auth_screen_close")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = TextSecondary
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // App Icon or Shield / Lock Icon with smooth animated state
            if (targetAppIcon != null) {
                Box(
                    modifier = Modifier.scale(successScale),
                    contentAlignment = Alignment.Center
                ) {
                    AppIcon(
                        drawable = targetAppIcon,
                        contentDescription = targetAppName ?: "Locked App",
                        modifier = Modifier.size(68.dp)
                    )
                    if (isSuccess) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .align(Alignment.BottomEnd)
                                .clip(CircleShape)
                                .background(AccentGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = "Unlocked",
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .scale(successScale)
                        .clip(CircleShape)
                        .background(iconBgColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isSuccess) Icons.Default.LockOpen else Icons.Default.Lock,
                        contentDescription = if (isSuccess) "Unlocked" else "Lock",
                        tint = iconTint,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = targetAppName ?: "Private App Locker",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Text(
                text = when {
                    isSuccess -> "Access granted • Unlocking..."
                    targetAppName != null -> "This application is locked for privacy"
                    else -> "Enter security code to access"
                },
                style = MaterialTheme.typography.bodySmall,
                color = if (isSuccess) AccentGreen else TextSecondary,
                fontWeight = if (isSuccess) FontWeight.SemiBold else FontWeight.Normal,
                modifier = Modifier.padding(top = 4.dp)
            )

            // Failed Attempts Alert
            if (failedAttempts > 0 && !isSuccess) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Incorrect code ($failedAttempts failed attempt${if (failedAttempts > 1) "s" else ""})",
                    color = AccentRed,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // PIN or PATTERN entry
            if (currentMethod == "PIN") {
                PinDotsIndicator(
                    pinLength = currentPin.length,
                    maxDigits = 4,
                    isError = isError,
                    isSuccess = isSuccess
                )

                Spacer(modifier = Modifier.height(16.dp))

                PinKeypad(
                    onDigitClick = { digit ->
                        if (!isSuccess && currentPin.length < 4) {
                            currentPin += digit
                            isError = false
                            if (currentPin.length == 4) {
                                val enteredHash = SecurityUtils.hashString(currentPin)
                                if (enteredHash == settings.pinHash) {
                                    // Success with transition animation
                                    triggerUnlockSuccess()
                                } else {
                                    // Failure
                                    isError = true
                                    failedAttempts++
                                    if (settings.vibrateOnInput) SecurityUtils.vibrateError(context)
                                    onIntruderAttempt(
                                        targetPackageName ?: context.packageName,
                                        targetAppName ?: "Private App Locker",
                                        failedAttempts,
                                        "•".repeat(currentPin.length)
                                    )
                                    currentPin = ""
                                }
                            }
                        }
                    },
                    onDeleteClick = {
                        if (!isSuccess && currentPin.isNotEmpty()) {
                            currentPin = currentPin.dropLast(1)
                            isError = false
                        }
                    },
                    isRandomized = settings.randomizeKeypad,
                    vibrateEnabled = settings.vibrateOnInput
                )
            } else {
                // Pattern Lock Entry
                PatternLockView(
                    onPatternComplete = { pattern ->
                        if (!isSuccess) {
                            val patternStr = SecurityUtils.patternToString(pattern)
                            if (patternStr == settings.patternData) {
                                triggerUnlockSuccess()
                            } else {
                                isError = true
                                failedAttempts++
                                if (settings.vibrateOnInput) SecurityUtils.vibrateError(context)
                                onIntruderAttempt(
                                    targetPackageName ?: context.packageName,
                                    targetAppName ?: "Private App Locker",
                                    failedAttempts,
                                    "PATTERN[${pattern.size}]"
                                )
                            }
                        }
                    },
                    isError = isError,
                    isSuccess = isSuccess,
                    vibrateEnabled = settings.vibrateOnInput
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Footer options: Forgot PIN? & Switch Lock Type (if both available)
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (settings.securityAnswerHash.isNotEmpty()) {
                    TextButton(
                        onClick = { showForgotDialog = true },
                        modifier = Modifier.testTag("forgot_pin_button")
                    ) {
                        Text(
                            text = "Forgot Code?",
                            color = CyberCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // If user set up pattern as alternate or wants to toggle
                if (settings.patternData.isNotEmpty() && settings.pinHash.isNotEmpty()) {
                    TextButton(
                        onClick = {
                            currentMethod = if (currentMethod == "PIN") "PATTERN" else "PIN"
                            currentPin = ""
                            isError = false
                        }
                    ) {
                        Text(
                            text = if (currentMethod == "PIN") "Use Pattern" else "Use PIN",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Forgot Code / Security Recovery Dialog
        if (showForgotDialog) {
            AlertDialog(
                onDismissRequest = {
                    showForgotDialog = false
                    recoveryAnswer = ""
                    recoveryError = false
                },
                title = {
                    Text("Security Recovery", fontWeight = FontWeight.Bold, color = TextPrimary)
                },
                text = {
                    Column {
                        Text(
                            text = settings.securityQuestion,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = recoveryAnswer,
                            onValueChange = {
                                recoveryAnswer = it
                                recoveryError = false
                            },
                            label = { Text("Your Answer") },
                            isError = recoveryError,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                        if (recoveryError) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Incorrect answer", color = AccentRed, fontSize = 12.sp)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val ansHash = SecurityUtils.hashString(recoveryAnswer)
                            if (ansHash == settings.securityAnswerHash) {
                                showForgotDialog = false
                                triggerUnlockSuccess()
                            } else {
                                recoveryError = true
                                SecurityUtils.vibrateError(context)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan)
                    ) {
                        Text("Verify & Unlock", color = Color(0xFF090D16), fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showForgotDialog = false }) {
                        Text("Cancel", color = TextSecondary)
                    }
                },
                containerColor = Color(0xFF1E293B)
            )
        }
    }
}
