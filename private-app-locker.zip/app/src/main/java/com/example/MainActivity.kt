package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.service.AppLockerForegroundService
import com.example.service.PermissionHelper
import com.example.ui.AppLockerViewModel
import com.example.ui.screens.AuthLockScreen
import com.example.ui.screens.MainContainerScreen
import com.example.ui.screens.SetupScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private lateinit var lockerViewModel: AppLockerViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val vm: AppLockerViewModel = viewModel()
                lockerViewModel = vm

                val settings by vm.settings.collectAsState()
                val isAuthenticated by vm.isAuthenticated.collectAsState()
                val isChangingPin by vm.isChangingPin.collectAsState()
                val installedApps by vm.installedApps.collectAsState()
                val lockedApps by vm.lockedApps.collectAsState()
                val intruderLogs by vm.intruderLogs.collectAsState()
                val vaultItems by vm.vaultItems.collectAsState()
                val isLoadingApps by vm.isLoadingApps.collectAsState()

                LaunchedEffect(settings) {
                    if (settings.isProtectionServiceActive && PermissionHelper.hasUsageStatsPermission(applicationContext)) {
                        AppLockerForegroundService.startService(applicationContext)
                    }
                }

                Crossfade(
                    targetState = Triple(settings, isAuthenticated, isChangingPin),
                    label = "main_flow_transition"
                ) { (secSettings, authed, changingPin) ->
                    when {
                        !secSettings.isSetupCompleted || changingPin -> {
                            // First time setup or Change PIN flow
                            SetupScreen(
                                onSetupComplete = { newSettings ->
                                    vm.completeSetup(newSettings)
                                }
                            )
                        }

                        !authed -> {
                            // Lock Gatekeeper for Private App Locker itself
                            AuthLockScreen(
                                settings = secSettings,
                                targetAppName = "Private App Locker",
                                onUnlockSuccess = { vm.authenticate() },
                                onIntruderAttempt = { pkg, name, count, code ->
                                    vm.recordIntruderAttempt(pkg, name, count, code)
                                },
                                onCloseOrExit = { finish() }
                            )
                        }

                        else -> {
                            // Main Application Console
                            MainContainerScreen(
                                settings = secSettings,
                                installedApps = installedApps,
                                lockedApps = lockedApps,
                                intruderLogs = intruderLogs,
                                vaultItems = vaultItems,
                                isLoadingApps = isLoadingApps,
                                onToggleLock = { app, locked -> vm.toggleAppLock(app, locked) },
                                onToggleCamouflage = { pkg, enabled -> vm.toggleCamouflage(pkg, enabled) },
                                onLockAllSensitive = { vm.lockAllSensitiveApps() },
                                onUnlockAll = { vm.unlockAllApps() },
                                onSaveVaultItem = { item -> vm.saveVaultItem(item) },
                                onDeleteVaultItem = { item -> vm.deleteVaultItem(item) },
                                onClearIntruderLogs = { vm.clearIntruderLogs() },
                                onDeleteIntruderLog = { id -> vm.deleteIntruderLog(id) },
                                onUpdateSettings = { newSettings -> vm.updateSettings(newSettings) },
                                onChangePinRequested = { vm.requestChangePin() },
                                onIntruderAttempt = { pkg, name, count, code ->
                                    vm.recordIntruderAttempt(pkg, name, count, code)
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::lockerViewModel.isInitialized) {
            lockerViewModel.loadInstalledApps()
        }
    }
}
