package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pattern
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SecuritySettingsEntity
import com.example.service.SecurityUtils
import com.example.ui.components.PatternLockView
import com.example.ui.components.PinDotsIndicator
import com.example.ui.components.PinKeypad
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentRed
import com.example.ui.theme.BorderDark
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

@Composable
fun SetupScreen(
    onSetupComplete: (SecuritySettingsEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedMethod by remember { mutableStateOf("PIN") } // "PIN" or "PATTERN"
    var setupStep by remember { mutableIntStateOf(1) } // 1: Enter, 2: Confirm, 3: Security Question

    // PIN state
    var initialPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var isPinError by remember { mutableStateOf(false) }
    var isPinSuccess by remember { mutableStateOf(false) }

    // Pattern state
    var initialPattern by remember { mutableStateOf<List<Int>>(emptyList()) }
    var confirmPattern by remember { mutableStateOf<List<Int>>(emptyList()) }
    var isPatternError by remember { mutableStateOf(false) }
    var isPatternSuccess by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    // Security Question state
    var securityQuestion by remember { mutableStateOf("What was the name of your first school?") }
    var securityAnswer by remember { mutableStateOf("") }
    var questionError by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepNavy)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Shield Header Icon
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(CyberCyan.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Shield",
                    tint = CyberCyan,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Private App Locker",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Text(
                text = when (setupStep) {
                    1 -> "Create your master security ${if (selectedMethod == "PIN") "PIN" else "Pattern"}"
                    2 -> "Confirm your master ${if (selectedMethod == "PIN") "PIN" else "Pattern"}"
                    else -> "Set up password recovery question"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Method Selector (Only during step 1)
            if (setupStep == 1) {
                TabRow(
                    selectedTabIndex = if (selectedMethod == "PIN") 0 else 1,
                    containerColor = Color(0xFF1E293B),
                    contentColor = CyberCyan,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[if (selectedMethod == "PIN") 0 else 1]),
                            color = CyberCyan
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth(0.75f)
                        .clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedMethod == "PIN",
                        onClick = {
                            selectedMethod = "PIN"
                            initialPin = ""
                        },
                        text = { Text("4-Digit PIN", fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.Pin, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = selectedMethod == "PATTERN",
                        onClick = {
                            selectedMethod = "PATTERN"
                            initialPattern = emptyList()
                        },
                        text = { Text("Pattern", fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.Pattern, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))
            }

            // Interactive Lock Pad or Recovery Form
            AnimatedContent(targetState = setupStep, label = "setup_step_transition") { step ->
                when (step) {
                    1 -> {
                        // Step 1: Initial Entry
                        if (selectedMethod == "PIN") {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                PinDotsIndicator(
                                    pinLength = initialPin.length,
                                    maxDigits = 4,
                                    isError = false
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                PinKeypad(
                                    onDigitClick = { digit ->
                                        if (initialPin.length < 4) {
                                            initialPin += digit
                                            if (initialPin.length == 4) {
                                                setupStep = 2
                                            }
                                        }
                                    },
                                    onDeleteClick = {
                                        if (initialPin.isNotEmpty()) {
                                            initialPin = initialPin.dropLast(1)
                                        }
                                    },
                                    isRandomized = false
                                )
                            }
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Connect at least 4 dots",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                                PatternLockView(
                                    onPatternComplete = { pattern ->
                                        if (pattern.size >= 4) {
                                            initialPattern = pattern
                                            setupStep = 2
                                        } else {
                                            SecurityUtils.vibrateError(context)
                                        }
                                    }
                                )
                            }
                        }
                    }
                    2 -> {
                        // Step 2: Confirm Entry
                        if (selectedMethod == "PIN") {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                PinDotsIndicator(
                                    pinLength = confirmPin.length,
                                    maxDigits = 4,
                                    isError = isPinError,
                                    isSuccess = isPinSuccess
                                )
                                if (isPinSuccess) {
                                    Text(
                                        text = "PIN matched! Saving...",
                                        color = AccentGreen,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                } else if (isPinError) {
                                    Text(
                                        text = "PINs do not match. Try again.",
                                        color = AccentRed,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                PinKeypad(
                                    onDigitClick = { digit ->
                                        if (!isPinSuccess && confirmPin.length < 4) {
                                            confirmPin += digit
                                            if (confirmPin.length == 4) {
                                                if (confirmPin == initialPin) {
                                                    isPinSuccess = true
                                                    isPinError = false
                                                    SecurityUtils.vibrateShort(context)
                                                    coroutineScope.launch {
                                                        delay(350)
                                                        setupStep = 3
                                                    }
                                                } else {
                                                    isPinError = true
                                                    SecurityUtils.vibrateError(context)
                                                    confirmPin = ""
                                                }
                                            }
                                        }
                                    },
                                    onDeleteClick = {
                                        if (!isPinSuccess && confirmPin.isNotEmpty()) {
                                            confirmPin = confirmPin.dropLast(1)
                                            isPinError = false
                                        }
                                    }
                                )
                            }
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = when {
                                        isPatternSuccess -> "Pattern matched! Saving..."
                                        isPatternError -> "Pattern doesn't match. Redraw."
                                        else -> "Redraw pattern to confirm"
                                    },
                                    fontSize = 13.sp,
                                    color = when {
                                        isPatternSuccess -> AccentGreen
                                        isPatternError -> AccentRed
                                        else -> TextSecondary
                                    },
                                    fontWeight = if (isPatternSuccess) FontWeight.SemiBold else FontWeight.Normal
                                )
                                PatternLockView(
                                    onPatternComplete = { pattern ->
                                        if (!isPatternSuccess) {
                                            if (pattern == initialPattern) {
                                                confirmPattern = pattern
                                                isPatternSuccess = true
                                                isPatternError = false
                                                SecurityUtils.vibrateShort(context)
                                                coroutineScope.launch {
                                                    delay(350)
                                                    setupStep = 3
                                                }
                                            } else {
                                                isPatternError = true
                                                SecurityUtils.vibrateError(context)
                                            }
                                        }
                                    },
                                    isError = isPatternError,
                                    isSuccess = isPatternSuccess
                                )
                            }
                        }
                    }
                    3 -> {
                        // Step 3: Security Question for password recovery
                        Card(
                            modifier = Modifier
                                .fillMaxWidth(0.92f)
                                .padding(vertical = 12.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Security Recovery Question",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "This allows you to recover access if you ever forget your master lock.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                OutlinedTextField(
                                    value = securityQuestion,
                                    onValueChange = { securityQuestion = it },
                                    label = { Text("Security Question") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyberCyan,
                                        unfocusedBorderColor = BorderDark,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    )
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = securityAnswer,
                                    onValueChange = {
                                        securityAnswer = it
                                        questionError = false
                                    },
                                    label = { Text("Your Answer") },
                                    isError = questionError,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyberCyan,
                                        unfocusedBorderColor = BorderDark,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    )
                                )

                                if (questionError) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Please enter an answer",
                                        color = AccentRed,
                                        fontSize = 12.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                Button(
                                    onClick = {
                                        if (securityAnswer.trim().isEmpty()) {
                                            questionError = true
                                            return@Button
                                        }

                                        val pinHash = if (selectedMethod == "PIN") SecurityUtils.hashString(initialPin) else ""
                                        val patternStr = if (selectedMethod == "PATTERN") SecurityUtils.patternToString(initialPattern) else ""
                                        val answerHash = SecurityUtils.hashString(securityAnswer)

                                        val entity = SecuritySettingsEntity(
                                            isSetupCompleted = true,
                                            pinHash = pinHash,
                                            patternData = patternStr,
                                            lockMethod = selectedMethod,
                                            securityQuestion = securityQuestion.trim(),
                                            securityAnswerHash = answerHash,
                                            relockTimeoutSeconds = 0,
                                            randomizeKeypad = false,
                                            vibrateOnInput = true,
                                            fakeCrashEnabled = false,
                                            isProtectionServiceActive = true
                                        )
                                        onSetupComplete(entity)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .testTag("complete_setup_button")
                                ) {
                                    Text(
                                        text = "Complete Setup & Protect",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF090D16),
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
