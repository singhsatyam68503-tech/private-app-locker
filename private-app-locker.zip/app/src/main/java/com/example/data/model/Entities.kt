package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "locked_apps")
data class LockedAppEntity(
    @PrimaryKey
    val packageName: String,
    val appName: String,
    val isLocked: Boolean = true,
    val lockType: String = "PIN",
    val lockedAt: Long = System.currentTimeMillis(),
    val lastAccessTime: Long = 0L,
    val isCamouflageEnabled: Boolean = false,
    val category: String = "OTHER"
)

@Entity(tableName = "intruder_logs")
data class IntruderLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val packageName: String,
    val appName: String,
    val failedAttempts: Int,
    val enteredCodeMasked: String = "••••"
)

@Entity(tableName = "private_vault_items")
data class PrivateVaultItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val content: String,
    val category: String = "NOTE", // NOTE, PASSWORD, DOCUMENT
    val timestamp: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
)

@Entity(tableName = "security_settings")
data class SecuritySettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val isSetupCompleted: Boolean = false,
    val pinHash: String = "",
    val patternData: String = "", // e.g. "0,1,2,4,6,7,8"
    val lockMethod: String = "PIN", // PIN or PATTERN
    val securityQuestion: String = "What was the name of your first school?",
    val securityAnswerHash: String = "",
    val relockTimeoutSeconds: Int = 0, // 0 = immediately, 60 = 1 min, 300 = 5 min
    val randomizeKeypad: Boolean = false,
    val vibrateOnInput: Boolean = true,
    val fakeCrashEnabled: Boolean = false,
    val isProtectionServiceActive: Boolean = true
)
