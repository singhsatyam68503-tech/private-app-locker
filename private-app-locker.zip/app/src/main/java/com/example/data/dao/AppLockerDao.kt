package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.IntruderLogEntity
import com.example.data.model.LockedAppEntity
import com.example.data.model.PrivateVaultItemEntity
import com.example.data.model.SecuritySettingsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AppLockerDao {

    // --- Locked Apps ---
    @Query("SELECT * FROM locked_apps ORDER BY appName ASC")
    fun getAllLockedApps(): Flow<List<LockedAppEntity>>

    @Query("SELECT * FROM locked_apps WHERE isLocked = 1")
    fun getActiveLockedApps(): Flow<List<LockedAppEntity>>

    @Query("SELECT packageName FROM locked_apps WHERE isLocked = 1")
    suspend fun getLockedPackageNames(): List<String>

    @Query("SELECT * FROM locked_apps WHERE packageName = :packageName LIMIT 1")
    suspend fun getLockedApp(packageName: String): LockedAppEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLockedApp(app: LockedAppEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLockedApps(apps: List<LockedAppEntity>)

    @Query("UPDATE locked_apps SET isLocked = :isLocked WHERE packageName = :packageName")
    suspend fun updateLockStatus(packageName: String, isLocked: Boolean)

    @Query("UPDATE locked_apps SET isCamouflageEnabled = :enabled WHERE packageName = :packageName")
    suspend fun updateCamouflage(packageName: String, enabled: Boolean)

    @Delete
    suspend fun deleteLockedApp(app: LockedAppEntity)

    // --- Intruder Logs ---
    @Query("SELECT * FROM intruder_logs ORDER BY timestamp DESC")
    fun getAllIntruderLogs(): Flow<List<IntruderLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIntruderLog(log: IntruderLogEntity)

    @Query("DELETE FROM intruder_logs")
    suspend fun clearAllIntruderLogs()

    @Query("DELETE FROM intruder_logs WHERE id = :id")
    suspend fun deleteIntruderLog(id: Long)

    // --- Private Vault Items ---
    @Query("SELECT * FROM private_vault_items ORDER BY isPinned DESC, timestamp DESC")
    fun getAllVaultItems(): Flow<List<PrivateVaultItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaultItem(item: PrivateVaultItemEntity)

    @Update
    suspend fun updateVaultItem(item: PrivateVaultItemEntity)

    @Delete
    suspend fun deleteVaultItem(item: PrivateVaultItemEntity)

    @Query("DELETE FROM private_vault_items WHERE id = :id")
    suspend fun deleteVaultItemById(id: Long)

    // --- Security Settings ---
    @Query("SELECT * FROM security_settings WHERE id = 1 LIMIT 1")
    fun getSecuritySettings(): Flow<SecuritySettingsEntity?>

    @Query("SELECT * FROM security_settings WHERE id = 1 LIMIT 1")
    suspend fun getSecuritySettingsSync(): SecuritySettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSecuritySettings(settings: SecuritySettingsEntity)
}
