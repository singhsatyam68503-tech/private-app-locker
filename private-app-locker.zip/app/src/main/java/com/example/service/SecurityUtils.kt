package com.example.service

import android.content.Context
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import java.security.MessageDigest

object SecurityUtils {

    fun hashString(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.trim().lowercase().toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun verifyHash(input: String, hash: String): Boolean {
        if (hash.isEmpty()) return false
        return hashString(input) == hash
    }

    fun getShuffledKeypad(): List<Int> {
        return (0..9).shuffled()
    }

    fun getStandardKeypad(): List<Int> {
        return listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 0)
    }

    fun patternToString(points: List<Int>): String {
        return points.joinToString(",")
    }

    fun stringToPattern(patternStr: String): List<Int> {
        if (patternStr.isBlank()) return emptyList()
        return patternStr.split(",").mapNotNull { it.trim().toIntOrNull() }
    }

    fun vibrateShort(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(35)
                }
            }
        } catch (_: Exception) {
            // Ignore if vibration is restricted
        }
    }

    fun vibrateError(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 70, 70, 70), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 70, 70, 70), -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(longArrayOf(0, 70, 70, 70), -1)
                }
            }
        } catch (_: Exception) {
            // Ignore
        }
    }
}
