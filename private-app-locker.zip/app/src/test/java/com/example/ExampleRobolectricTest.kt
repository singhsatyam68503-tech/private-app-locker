package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppLockerDatabase
import com.example.data.model.LockedAppEntity
import com.example.data.model.SecuritySettingsEntity
import com.example.service.SecurityUtils
import com.example.service.SessionManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Private App Locker", appName)
    }

    @Test
    fun `test security utils hashing and pattern conversion`() {
        val pin = "1234"
        val hash1 = SecurityUtils.hashString(pin)
        val hash2 = SecurityUtils.hashString(pin)
        assertEquals(hash1, hash2)
        assertFalse(hash1 == pin)

        val pattern = listOf(0, 1, 2, 5, 8)
        val patternStr = SecurityUtils.patternToString(pattern)
        assertEquals("0,1,2,5,8", patternStr)
    }

    @Test
    fun `test session manager unlock and lock policy`() {
        val pkg = "com.android.chrome"
        SessionManager.unlockPackage(pkg, timeoutSeconds = 60)
        assertTrue(SessionManager.isPackageUnlocked(pkg))

        SessionManager.lockPackage(pkg)
        assertFalse(SessionManager.isPackageUnlocked(pkg))
    }

    @Test
    fun `test database operations`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = AppLockerDatabase.getInstance(context)
        val dao = db.appLockerDao()

        val settings = SecuritySettingsEntity(
            isSetupCompleted = true,
            pinHash = SecurityUtils.hashString("1234"),
            lockMethod = "PIN",
            securityQuestion = "Favorite color?",
            securityAnswerHash = SecurityUtils.hashString("cyan")
        )
        dao.saveSecuritySettings(settings)

        val fetched = dao.getSecuritySettingsSync()
        assertEquals("PIN", fetched?.lockMethod)
        assertEquals("Favorite color?", fetched?.securityQuestion)

        val lockedApp = LockedAppEntity(
            packageName = "com.test.app",
            appName = "Test App",
            isLocked = true,
            category = "SOCIAL"
        )
        dao.insertLockedApp(lockedApp)

        val app = dao.getLockedApp("com.test.app")
        assertNotNull(app)
        assertTrue(app?.isLocked == true)

        // Test toggling lock in Room database
        dao.updateLockStatus("com.test.app", false)
        val updatedApp = dao.getLockedApp("com.test.app")
        assertNotNull(updatedApp)
        assertFalse(updatedApp?.isLocked == true)

        // Toggle back to locked
        dao.updateLockStatus("com.test.app", true)
        val lockedAgainApp = dao.getLockedApp("com.test.app")
        assertNotNull(lockedAgainApp)
        assertTrue(lockedAgainApp?.isLocked == true)
    }
}
