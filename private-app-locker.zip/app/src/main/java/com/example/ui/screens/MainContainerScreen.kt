package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.IntruderLogEntity
import com.example.data.model.LockedAppEntity
import com.example.data.model.PrivateVaultItemEntity
import com.example.data.model.SecuritySettingsEntity
import com.example.service.InstalledAppInfo
import com.example.service.SessionManager
import com.example.ui.components.FakeCrashDialog
import com.example.ui.theme.AccentRed
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

sealed class LockerTab(val title: String, val icon: ImageVector, val tag: String) {
    data object AppLock : LockerTab("App Lock", Icons.Default.Lock, "tab_app_lock")
    data object Vault : LockerTab("Vault", Icons.Default.Security, "tab_vault")
    data object Intruders : LockerTab("Intruders", Icons.Default.Warning, "tab_intruders")
    data object Settings : LockerTab("Settings", Icons.Default.Settings, "tab_settings")
}

@Composable
fun MainContainerScreen(
    settings: SecuritySettingsEntity,
    installedApps: List<InstalledAppInfo>,
    lockedApps: List<LockedAppEntity>,
    intruderLogs: List<IntruderLogEntity>,
    vaultItems: List<PrivateVaultItemEntity>,
    isLoadingApps: Boolean = false,
    onToggleLock: (InstalledAppInfo, Boolean) -> Unit,
    onToggleCamouflage: (String, Boolean) -> Unit,
    onLockAllSensitive: () -> Unit,
    onUnlockAll: () -> Unit,
    onSaveVaultItem: (PrivateVaultItemEntity) -> Unit,
    onDeleteVaultItem: (PrivateVaultItemEntity) -> Unit,
    onClearIntruderLogs: () -> Unit,
    onDeleteIntruderLog: (Long) -> Unit,
    onUpdateSettings: (SecuritySettingsEntity) -> Unit,
    onChangePinRequested: () -> Unit,
    onIntruderAttempt: (packageName: String, appName: String, failedCount: Int, maskedCode: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        LockerTab.AppLock,
        LockerTab.Vault,
        LockerTab.Intruders,
        LockerTab.Settings
    )

    // Test Lock Simulation Modal State
    var testAppInfo by remember { mutableStateOf<InstalledAppInfo?>(null) }
    var isTestCamouflageActive by remember { mutableStateOf(false) }
    var isCamouflageShowing by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                NavigationBar(
                    containerColor = Color(0xFF0F172A),
                    contentColor = TextPrimary,
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("main_navigation_bar")
                ) {
                    tabs.forEachIndexed { index, tab ->
                        val isSelected = selectedTab == index
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { selectedTab = index },
                            icon = {
                                if (tab is LockerTab.Intruders && intruderLogs.isNotEmpty()) {
                                    BadgedBox(badge = {
                                        Badge(containerColor = AccentRed) {
                                            Text("${intruderLogs.size}", color = Color.White, fontSize = 10.sp)
                                        }
                                    }) {
                                        Icon(imageVector = tab.icon, contentDescription = tab.title)
                                    }
                                } else {
                                    Icon(imageVector = tab.icon, contentDescription = tab.title)
                                }
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color(0xFF090D16),
                                selectedTextColor = CyberCyan,
                                indicatorColor = CyberCyan,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            ),
                            modifier = Modifier.testTag(tab.tag)
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(DeepNavy)
            ) {
                when (selectedTab) {
                    0 -> AppListScreen(
                        installedApps = installedApps,
                        lockedApps = lockedApps,
                        isLoading = isLoadingApps,
                        onToggleLock = onToggleLock,
                        onToggleCamouflage = onToggleCamouflage,
                        onLockAllSensitive = onLockAllSensitive,
                        onUnlockAll = onUnlockAll,
                        onTestLock = { app, isCamouflage ->
                            testAppInfo = app
                            isTestCamouflageActive = isCamouflage
                            isCamouflageShowing = isCamouflage
                        },
                        onOpenPermissions = { selectedTab = 3 }
                    )
                    1 -> PrivateVaultScreen(
                        vaultItems = vaultItems,
                        onSaveItem = onSaveVaultItem,
                        onDeleteItem = onDeleteVaultItem
                    )
                    2 -> IntruderLogsScreen(
                        logs = intruderLogs,
                        onClearLogs = onClearIntruderLogs,
                        onDeleteLog = onDeleteIntruderLog
                    )
                    3 -> SettingsScreen(
                        settings = settings,
                        onUpdateSettings = onUpdateSettings,
                        onChangePinRequested = onChangePinRequested,
                        onResetAllLocks = onUnlockAll
                    )
                }
            }
        }

        // Live Test Simulation Overlay
        testAppInfo?.let { app ->
            AnimatedVisibility(
                visible = isCamouflageShowing,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                FakeCrashDialog(
                    appName = app.appName,
                    onRevealLock = { isCamouflageShowing = false },
                    onRealExit = { testAppInfo = null }
                )
            }

            if (!isCamouflageShowing) {
                AnimatedVisibility(
                    visible = true,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    AuthLockScreen(
                        settings = settings,
                        targetAppName = app.appName,
                        targetAppIcon = app.icon,
                        targetPackageName = app.packageName,
                        onUnlockSuccess = {
                            testAppInfo = null
                            SessionManager.unlockPackage(app.packageName, settings.relockTimeoutSeconds)
                            Toast.makeText(context, "${app.appName} Unlocked Successfully!", Toast.LENGTH_SHORT).show()
                        },
                        onIntruderAttempt = { pkg, name, count, code ->
                            onIntruderAttempt(pkg, name, count, code)
                        },
                        onCloseOrExit = { testAppInfo = null }
                    )
                }
            }
        }
    }
}
