package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.service.SecurityUtils
import com.example.ui.theme.AccentRed
import com.example.ui.theme.CyberCyan
import kotlin.math.hypot

@Composable
fun PatternLockView(
    onPatternComplete: (List<Int>) -> Unit,
    isError: Boolean = false,
    isSuccess: Boolean = false,
    vibrateEnabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedIndices = remember { mutableStateListOf<Int>() }
    var currentTouchPos by remember { mutableStateOf<Offset?>(null) }

    val lineColor = when {
        isError -> AccentRed
        isSuccess -> com.example.ui.theme.AccentGreen
        else -> CyberCyan
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .padding(32.dp)
            .testTag("pattern_lock_view"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .matchParentSize()
                .pointerInput(isError) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            selectedIndices.clear()
                            currentTouchPos = offset
                            val dotIndex = getTouchedDot(offset, size.width.toFloat(), size.height.toFloat())
                            if (dotIndex != -1) {
                                selectedIndices.add(dotIndex)
                                if (vibrateEnabled) SecurityUtils.vibrateShort(context)
                            }
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val pos = change.position
                            currentTouchPos = pos
                            val dotIndex = getTouchedDot(pos, size.width.toFloat(), size.height.toFloat())
                            if (dotIndex != -1 && !selectedIndices.contains(dotIndex)) {
                                selectedIndices.add(dotIndex)
                                if (vibrateEnabled) SecurityUtils.vibrateShort(context)
                            }
                        },
                        onDragEnd = {
                            currentTouchPos = null
                            if (selectedIndices.isNotEmpty()) {
                                onPatternComplete(selectedIndices.toList())
                            }
                        },
                        onDragCancel = {
                            currentTouchPos = null
                            selectedIndices.clear()
                        }
                    )
                }
        ) {
            val width = size.width
            val height = size.height
            val cellW = width / 3f
            val cellH = height / 3f
            val dotRadius = 9.dp.toPx()
            val outerDotRadius = 26.dp.toPx()

            // Precompute 9 dot positions
            val dotPositions = List(9) { index ->
                val col = index % 3
                val row = index / 3
                Offset(col * cellW + cellW / 2f, row * cellH + cellH / 2f)
            }

            // 1. Draw connecting lines between selected dots
            if (selectedIndices.size > 1) {
                for (i in 0 until selectedIndices.size - 1) {
                    val p1 = dotPositions[selectedIndices[i]]
                    val p2 = dotPositions[selectedIndices[i + 1]]
                    drawLine(
                        color = lineColor,
                        start = p1,
                        end = p2,
                        strokeWidth = 6.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // 2. Draw line from last selected dot to current finger touch
            currentTouchPos?.let { touchPos ->
                if (selectedIndices.isNotEmpty()) {
                    val lastDot = dotPositions[selectedIndices.last()]
                    drawLine(
                        color = lineColor.copy(alpha = 0.6f),
                        start = lastDot,
                        end = touchPos,
                        strokeWidth = 4.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // 3. Draw 9 dots
            dotPositions.forEachIndexed { index, pos ->
                val isSelected = selectedIndices.contains(index)
                if (isSelected) {
                    // Outer glow circle
                    drawCircle(
                        color = lineColor.copy(alpha = 0.25f),
                        radius = outerDotRadius,
                        center = pos
                    )
                    // Inner dot
                    drawCircle(
                        color = lineColor,
                        radius = dotRadius * 1.2f,
                        center = pos
                    )
                } else {
                    // Inactive dot
                    drawCircle(
                        color = Color(0xFF475569),
                        radius = dotRadius,
                        center = pos
                    )
                }
            }
        }
    }
}

private fun getTouchedDot(offset: Offset, width: Float, height: Float): Int {
    val cellW = width / 3f
    val cellH = height / 3f
    val threshold = 36f * 3f // touch tolerance

    for (index in 0 until 9) {
        val col = index % 3
        val row = index / 3
        val center = Offset(col * cellW + cellW / 2f, row * cellH + cellH / 2f)
        val dist = hypot((offset.x - center.x).toDouble(), (offset.y - center.y).toDouble()).toFloat()
        if (dist <= threshold) {
            return index
        }
    }
    return -1
}
