package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Pattern
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SecuritySettingsEntity
import com.example.service.PermissionHelper
import com.example.service.SecurityUtils
import com.example.service.SessionManager
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentRed
import com.example.ui.theme.BorderDark
import com.example.ui.theme.CardSlate
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    settings: SecuritySettingsEntity,
    onUpdateSettings: (SecuritySettingsEntity) -> Unit,
    onChangePinRequested: () -> Unit,
    onResetAllLocks: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showQuestionDialog by remember { mutableStateOf(false) }
    var newQuestion by remember { mutableStateOf(settings.securityQuestion) }
    var newAnswer by remember { mutableStateOf("") }
    var showTimeoutDialog by remember { mutableStateOf(false) }

    val hasUsageAccess = remember { PermissionHelper.hasUsageStatsPermission(context) }
    val hasOverlay = remember { PermissionHelper.hasOverlayPermission(context) }
    val hasNotification = remember { PermissionHelper.hasNotificationPermission(context) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepNavy)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 100.dp)
    ) {
        // Top Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F172A))
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(CyberCyan.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Settings",
                        tint = CyberCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Security Settings",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Permissions, locks & privacy preferences",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // SECTION 1: System Permissions Wizard
        SettingsSectionTitle(title = "System Permissions")
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CardSlate),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderDark))
        ) {
            Column {
                PermissionItem(
                    title = "Usage Access",
                    description = "Required to detect when locked apps are opened",
                    isGranted = hasUsageAccess,
                    onGrantClick = { PermissionHelper.openUsageStatsSettings(context) }
                )
                SettingsDivider()
                PermissionItem(
                    title = "Display Over Other Apps",
                    description = "Required to show the lock screen over protected apps",
                    isGranted = hasOverlay,
                    onGrantClick = { PermissionHelper.openOverlaySettings(context) }
                )
                SettingsDivider()
                PermissionItem(
                    title = "Notifications",
                    description = "Keeps the protection service persistent and active",
                    isGranted = hasNotification,
                    onGrantClick = {}
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION 2: Master Lock Credentials
        SettingsSectionTitle(title = "Authentication Credentials")
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CardSlate),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderDark))
        ) {
            Column {
                // Lock Method Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (settings.lockMethod == "PIN") Icons.Default.Pin else Icons.Default.Pattern,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Lock Method", fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 14.sp)
                            Text("Current: ${if (settings.lockMethod == "PIN") "4-Digit PIN" else "Pattern"}", fontSize = 12.sp, color = TextSecondary)
                        }
                    }

                    Surface(
                        onClick = {
                            val newMethod = if (settings.lockMethod == "PIN") "PATTERN" else "PIN"
                            onUpdateSettings(settings.copy(lockMethod = newMethod))
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF0F172A),
                        modifier = Modifier.testTag("switch_lock_method_button")
                    ) {
                        Text(
                            text = "Switch to ${if (settings.lockMethod == "PIN") "Pattern" else "PIN"}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyan,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                SettingsDivider()

                // Change PIN / Pattern Button
                SettingsClickableItem(
                    icon = Icons.Default.Key,
                    title = "Change Master ${if (settings.lockMethod == "PIN") "PIN" else "Pattern"}",
                    subtitle = "Set a new master security passcode",
                    onClick = onChangePinRequested
                )

                SettingsDivider()

                // Security Question
                SettingsClickableItem(
                    icon = Icons.Default.QuestionAnswer,
                    title = "Password Recovery Question",
                    subtitle = settings.securityQuestion,
                    onClick = { showQuestionDialog = true }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION 3: Locking Preferences
        SettingsSectionTitle(title = "Locking Preferences")
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CardSlate),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderDark))
        ) {
            Column {
                // Re-lock Timeout
                SettingsClickableItem(
                    icon = Icons.Default.Timer,
                    title = "Re-Lock Policy",
                    subtitle = when (settings.relockTimeoutSeconds) {
                        0 -> "Immediately upon leaving app"
                        60 -> "After 1 minute of inactivity"
                        300 -> "After 5 minutes of inactivity"
                        else -> "Immediately"
                    },
                    onClick = { showTimeoutDialog = true }
                )

                SettingsDivider()

                // Randomize Keypad
                SettingsSwitchItem(
                    icon = Icons.Default.Shuffle,
                    title = "Randomize Keypad",
                    subtitle = "Shuffle number positions to prevent shoulder-surfing",
                    checked = settings.randomizeKeypad,
                    onCheckedChange = { onUpdateSettings(settings.copy(randomizeKeypad = it)) }
                )

                SettingsDivider()

                // Fake Crash Camouflage
                SettingsSwitchItem(
                    icon = Icons.Default.VisibilityOff,
                    title = "Fake Crash Camouflage",
                    subtitle = "Display fake 'App has stopped' screen before unlock",
                    checked = settings.fakeCrashEnabled,
                    onCheckedChange = { onUpdateSettings(settings.copy(fakeCrashEnabled = it)) }
                )

                SettingsDivider()

                // Vibrate on input
                SettingsSwitchItem(
                    icon = Icons.Default.Vibration,
                    title = "Haptic Feedback",
                    subtitle = "Vibrate on keypad and pattern touch input",
                    checked = settings.vibrateOnInput,
                    onCheckedChange = { onUpdateSettings(settings.copy(vibrateOnInput = it)) }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION 4: Emergency Actions
        SettingsSectionTitle(title = "Emergency Actions")
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CardSlate),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderDark))
        ) {
            Column {
                SettingsClickableItem(
                    icon = Icons.Default.Lock,
                    title = "Lock All Sessions Immediately",
                    subtitle = "Expires all temporary unlock tokens right now",
                    onClick = {
                        SessionManager.lockAll()
                        Toast.makeText(context, "All apps and sessions locked", Toast.LENGTH_SHORT).show()
                    }
                )

                SettingsDivider()

                SettingsClickableItem(
                    icon = Icons.Default.LockReset,
                    title = "Reset All App Locks",
                    subtitle = "Unlock all protected apps at once",
                    titleColor = AccentRed,
                    onClick = onResetAllLocks
                )
            }
        }

        // Dialog: Security Question
        if (showQuestionDialog) {
            AlertDialog(
                onDismissRequest = { showQuestionDialog = false },
                title = { Text("Update Recovery Question", fontWeight = FontWeight.Bold, color = TextPrimary) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = newQuestion,
                            onValueChange = { newQuestion = it },
                            label = { Text("Security Question") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                        OutlinedTextField(
                            value = newAnswer,
                            onValueChange = { newAnswer = it },
                            label = { Text("New Answer") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newQuestion.isNotBlank() && newAnswer.isNotBlank()) {
                                val answerHash = SecurityUtils.hashString(newAnswer)
                                onUpdateSettings(
                                    settings.copy(
                                        securityQuestion = newQuestion.trim(),
                                        securityAnswerHash = answerHash
                                    )
                                )
                                showQuestionDialog = false
                                Toast.makeText(context, "Recovery question updated", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan)
                    ) {
                        Text("Save", color = Color(0xFF090D16), fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showQuestionDialog = false }) {
                        Text("Cancel", color = TextSecondary)
                    }
                },
                containerColor = Color(0xFF1E293B)
            )
        }

        // Dialog: Re-lock Timeout
        if (showTimeoutDialog) {
            AlertDialog(
                onDismissRequest = { showTimeoutDialog = false },
                title = { Text("Select Re-Lock Policy", fontWeight = FontWeight.Bold, color = TextPrimary) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            0 to "Immediately upon leaving app",
                            60 to "After 1 minute of inactivity",
                            300 to "After 5 minutes of inactivity"
                        ).forEach { (seconds, label) ->
                            Surface(
                                onClick = {
                                    onUpdateSettings(settings.copy(relockTimeoutSeconds = seconds))
                                    showTimeoutDialog = false
                                },
                                shape = RoundedCornerShape(8.dp),
                                color = if (settings.relockTimeoutSeconds == seconds) CyberCyan.copy(alpha = 0.15f) else Color.Transparent,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = label,
                                    color = if (settings.relockTimeoutSeconds == seconds) CyberCyan else TextPrimary,
                                    fontWeight = if (settings.relockTimeoutSeconds == seconds) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showTimeoutDialog = false }) {
                        Text("Close", color = TextSecondary)
                    }
                },
                containerColor = Color(0xFF1E293B)
            )
        }
    }
}

@Composable
fun SettingsSectionTitle(title: String) {
    Text(
        text = title.uppercase(),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = CyberCyan,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
    )
}

@Composable
fun SettingsDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(BorderDark)
    )
}

@Composable
fun PermissionItem(
    title: String,
    description: String,
    isGranted: Boolean,
    onGrantClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Error,
                    contentDescription = null,
                    tint = if (isGranted) AccentGreen else AccentAmber,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(title, fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 14.sp)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(description, fontSize = 11.sp, color = TextSecondary)
        }

        Spacer(modifier = Modifier.width(8.dp))

        if (!isGranted) {
            Button(
                onClick = onGrantClick,
                colors = ButtonDefaults.buttonColors(containerColor = AccentAmber),
                shape = RoundedCornerShape(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text("Grant", color = Color(0xFF090D16), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        } else {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = AccentGreen.copy(alpha = 0.15f)
            ) {
                Text(
                    text = "Active",
                    fontSize = 11.sp,
                    color = AccentGreen,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
fun SettingsClickableItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    titleColor: Color = TextPrimary,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(title, fontWeight = FontWeight.SemiBold, color = titleColor, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(subtitle, fontSize = 11.sp, color = TextSecondary)
                }
            }
            Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
fun SettingsSwitchItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Text(subtitle, fontSize = 11.sp, color = TextSecondary)
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF090D16),
                checkedTrackColor = CyberCyan,
                uncheckedThumbColor = Color(0xFF94A3B8),
                uncheckedTrackColor = Color(0xFF334155)
            )
        )
    }
}
