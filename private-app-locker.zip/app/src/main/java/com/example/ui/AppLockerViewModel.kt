package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppLockerDatabase
import com.example.data.model.IntruderLogEntity
import com.example.data.model.LockedAppEntity
import com.example.data.model.PrivateVaultItemEntity
import com.example.data.model.SecuritySettingsEntity
import com.example.data.repository.AppLockerRepository
import com.example.service.AppLockerForegroundService
import com.example.service.InstalledAppInfo
import com.example.service.PermissionHelper
import com.example.service.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppLockerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppLockerRepository
    val settings: StateFlow<SecuritySettingsEntity>
    val lockedApps: StateFlow<List<LockedAppEntity>>
    val intruderLogs: StateFlow<List<IntruderLogEntity>>
    val vaultItems: StateFlow<List<PrivateVaultItemEntity>>

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _isLoadingApps = MutableStateFlow(true)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _isChangingPin = MutableStateFlow(false)
    val isChangingPin: StateFlow<Boolean> = _isChangingPin.asStateFlow()

    init {
        val db = AppLockerDatabase.getInstance(application)
        repository = AppLockerRepository(db.appLockerDao(), application)

        settings = repository.securitySettings
            .map { it ?: SecuritySettingsEntity(isSetupCompleted = false) }
            .stateIn(
                viewModelScope,
                SharingStarted.Eagerly,
                SecuritySettingsEntity(isSetupCompleted = false)
            )

        lockedApps = repository.allLockedApps
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        intruderLogs = repository.intruderLogs
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        vaultItems = repository.vaultItems
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        loadInstalledApps()
    }

    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoadingApps.value = true
            try {
                val apps = repository.getInstalledApps()
                _installedApps.value = apps
            } finally {
                _isLoadingApps.value = false
            }
        }
    }

    fun authenticate() {
        _isAuthenticated.value = true
        SessionManager.isMainAppUnlocked = true
    }

    fun completeSetup(newSettings: SecuritySettingsEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveSettings(newSettings)
            _isAuthenticated.value = true
            _isChangingPin.value = false
            SessionManager.isMainAppUnlocked = true

            // Automatically start background protection service if permissions are granted
            val context = getApplication<Application>()
            if (PermissionHelper.hasUsageStatsPermission(context)) {
                AppLockerForegroundService.startService(context)
            }
        }
    }

    fun toggleAppLock(appInfo: InstalledAppInfo, isCurrentlyLocked: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleAppLock(
                packageName = appInfo.packageName,
                appName = appInfo.appName,
                category = appInfo.category,
                isCurrentlyLocked = isCurrentlyLocked
            )
        }
    }

    fun toggleCamouflage(packageName: String, enabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.setCamouflage(packageName, enabled)
        }
    }

    fun lockAllSensitiveApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val sensitiveApps = _installedApps.value.filter {
                it.isRecommended || it.category == "SOCIAL" || it.category == "FINANCE"
            }
            repository.lockMultipleApps(sensitiveApps)
        }
    }

    fun unlockAllApps() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.unlockAllApps()
        }
    }

    fun saveVaultItem(item: PrivateVaultItemEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveVaultItem(item)
        }
    }

    fun deleteVaultItem(item: PrivateVaultItemEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteVaultItem(item)
        }
    }

    fun clearIntruderLogs() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearIntruderLogs()
        }
    }

    fun deleteIntruderLog(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteIntruderLog(id)
        }
    }

    fun recordIntruderAttempt(packageName: String, appName: String, count: Int, code: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.recordIntruderAttempt(packageName, appName, count, code)
        }
    }

    fun updateSettings(newSettings: SecuritySettingsEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveSettings(newSettings)
            val context = getApplication<Application>()
            if (newSettings.isProtectionServiceActive && PermissionHelper.hasUsageStatsPermission(context)) {
                AppLockerForegroundService.startService(context)
            } else {
                AppLockerForegroundService.stopService(context)
            }
        }
    }

    fun requestChangePin() {
        _isChangingPin.value = true
    }

    fun cancelChangePin() {
        _isChangingPin.value = false
    }
}
